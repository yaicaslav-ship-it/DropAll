package com.example.dropall;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

public class DropAllClient implements ClientModInitializer {
    private static final int BUTTON_W = 80;
    private static final int BUTTON_H = 16;

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof InventoryScreen inv)) return;

            ButtonWidget button = ButtonWidget.builder(
                    Text.translatable("button.dropall.drop_all"),
                    b -> dropAll(client))
                .dimensions(0, 0, BUTTON_W, BUTTON_H)
                .build();

            Screens.getButtons(screen).add(button);

            // Каждый кадр ставим кнопку над правым верхним углом окна инвентаря
            // (учитывает сдвиг окна при открытой книге рецептов).
            ScreenEvents.beforeRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) ->
                button.setPosition(inv.x + inv.backgroundWidth - BUTTON_W, inv.y - BUTTON_H - 2));
        });
    }

    private static void dropAll(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        ClientPlayerInteractionManager im = client.interactionManager;
        if (player == null || im == null) return;

        ScreenHandler handler = player.playerScreenHandler;

        // Если на курсоре что-то лежит — выбросить сначала это
        if (!handler.getCursorStack().isEmpty()) {
            im.clickSlot(handler.syncId, ScreenHandler.EMPTY_SPACE_SLOT_INDEX, 0, SlotActionType.PICKUP, player);
        }

        for (Slot slot : handler.slots) {
            if (slot.id == 0) continue;      // слот результата крафта — пропускаем
            if (!slot.hasStack()) continue;
            // THROW + button 1 = выбросить весь стак (как Ctrl+Q)
            im.clickSlot(handler.syncId, slot.id, 1, SlotActionType.THROW, player);
        }
    }
}
